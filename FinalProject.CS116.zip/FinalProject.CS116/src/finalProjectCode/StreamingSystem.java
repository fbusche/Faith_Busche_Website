package finalProjectCode;

import java.util.*;

public class StreamingSystem {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		Playlist playlist1 = null;
		
		UserMenu menu1 = null;
		
		User mainUser = new User("Faith");
		System.out.println("Your user name is: " + mainUser.getUserName() + " and your user ID is: " + mainUser.getID());
		
		System.out.println("Running system...");
		
		System.out.println("Please enter your user name.");
		String enteredName = scan.nextLine();
		
		System.out.println("Please enter your user ID");
		int enteredID = scan.nextInt();
		
		if (enteredID == mainUser.getID()) {
			System.out.println("Choose an option from the menu: \n"
					+ "1: Add \n"
					+ "2: Remove \n"
					+ "3: Play \n"
					+ "4: Save \n"
					+ "5: Display Statistics \n"
					+ "6: Exit System");

			int enteredOption = scan.nextInt();
			int response = 0;
			switch (enteredOption) {
				case 1:
					System.out.println("Choose an option from the add menu: \n"
							+ "1: Add user \n"
							+ "2: Add video recording \n"
							+ "3: Add audio recording \n");
					response = scan.nextInt();
						switch (response) {
							case 1:
								System.out.println("Enter the name of the user: ");
								String newName = scan.nextLine();
								menu1.addUser(newName);
								break;
							case 2:
								System.out.println("Who is the recording artist");
								String videoRecordingArtist = scan.nextLine();
								System.out.println("What is the recording name");
								String videoRecordingName = scan.nextLine();
								System.out.println("What is the recording length");
								double videoRecordingLength = scan.nextDouble();
								System.out.println("What is the recording size");
								double videoRecordingSize = scan.nextDouble();
								VideoRecording newRecording = new VideoRecording(videoRecordingArtist, videoRecordingName, videoRecordingLength, videoRecordingSize);
								playlist1.addRecording(newRecording);
								break;
							case 3:
								System.out.println("Who is the recording artist");
								String audioRecordingArtist = scan.nextLine();
								System.out.println("What is the recording name");
								String audioRecordingName = scan.nextLine();
								System.out.println("What is the recording length");
								double audioRecordingLength = scan.nextDouble();
								System.out.println("What is the recording size");
								double audioRecordingSize = scan.nextDouble();
								AudioRecording thisRecording = new AudioRecording(audioRecordingArtist, audioRecordingName, audioRecordingLength, audioRecordingSize);
								playlist1.addRecording(thisRecording);
								break;
						}
					
					break;
				case 2:
					System.out.println("Choose an option from the remove menu: \n"
							+ "1: Remove user \n"
							+ "2: Remove video recording \n"
							+ "3: Remove audio recording \n");
					response = scan.nextInt();
					
					switch (response) {
					case 1:
						System.out.println("Enter the name of the user: ");
						String newName = scan.nextLine();
						menu1.removeUser(newName);
						break;
					case 2:
						System.out.println("Would you like to remove by name or index?");
						String preference = scan.nextLine();
						if (preference == "name") {
							System.out.println("Enter the name of the video recording");
							String videoName = scan.nextLine();
							playlist1.removeRecording(videoName, true);
						}
						else if (preference == "index") {
							System.out.println("Enter the index of the video recording");
							int videoIndex = scan.nextInt();
							playlist1.removeRecording(videoIndex, true);
						}
						break;
					case 3:
						System.out.println("Would you like to remove by name or index?");
						String answer = scan.nextLine();
						if (answer == "name") {
							System.out.println("Enter the name of the audio recording");
							String audioName = scan.nextLine();
							playlist1.removeRecording(audioName, false);
						}
						else if (answer == "index") {
							System.out.println("Enter the index of the audio recording");
							int audioIndex = scan.nextInt();
							playlist1.removeRecording(audioIndex, false);
						}
						break;
				}
					break;
				case 3:
					System.out.println("Choose an option from the play menu: \n"
							+ "1: Play playlist \n"
							+ "2: Play video recording \n"
							+ "3: Play audio recording \n");
					response = scan.nextInt();
					
					switch (response) {
					case 1:
						System.out.println("What is the playlist name");
						String thisPlaylist = scan.nextLine();
						playlist1.play();
						break;
					case 2:
						System.out.println("Who is the recording artist");
						String videoRecordingArtist = scan.nextLine();
						System.out.println("What is the recording name");
						String videoRecordingName = scan.nextLine();
						System.out.println("What is the recording length");
						double videoRecordingLength = scan.nextDouble();
						System.out.println("What is the recording size");
						double videoRecordingSize = scan.nextDouble();
						VideoRecording thisRecording = new VideoRecording(videoRecordingArtist, videoRecordingName, videoRecordingLength, videoRecordingSize);
						thisRecording.play();
						break;
					case 3:
						System.out.println("Who is the recording artist");
						String audioRecordingArtist = scan.nextLine();
						System.out.println("What is the recording name");
						String audioRecordingName = scan.nextLine();
						System.out.println("What is the recording length");
						double audioRecordingLength = scan.nextDouble();
						System.out.println("What is the recording size");
						double audioRecordingSize = scan.nextDouble();
						AudioRecording thisAudioRecording = new AudioRecording(audioRecordingArtist, audioRecordingName, audioRecordingLength, audioRecordingSize);
						thisAudioRecording.play();
						break;
				}
					
					break;
				case 4:
					System.out.println("Playlist for " + mainUser.getUserName()
								+ " is being saved");
					break;
				case 5:
					System.out.println(playlist1.statistics());
					break;
				case 6:
					System.out.println("You are now logged out.");
					break;
			}
			System.out.println("You have chosen: " + response);
					
		}
		else System.out.println("Incorrect login info");
		
	
		scan.close();
		
	}

}
