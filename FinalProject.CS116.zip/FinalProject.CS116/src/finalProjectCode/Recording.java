package finalProjectCode;

public abstract class Recording implements Playable{
	
	public String artistName;
	public String recordingName;
	public double recordingLength;
	public double recordingSize;
	

	public void play() {
		System.out.println("No recording is playing");
		
	}
	
	
	
}
