package finalProjectCode;

public interface Playable {

	public abstract void play();
	
}
