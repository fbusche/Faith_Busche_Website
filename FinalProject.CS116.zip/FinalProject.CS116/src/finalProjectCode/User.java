package finalProjectCode;

public class User {

	private static int userID = 0;
	private String userName;
	
	public User () {
		userID++;
		userName = "Faith";
	}
	
	public User (String userName) {
		this.userName = userName;
		userID++;
	}
	
	public int getID () {
		return userID;
	}
	
	public String getUserName() {
		return userName;
	}
	
	
	
}
