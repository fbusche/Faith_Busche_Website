package finalProjectCode;

public class AudioRecording extends Recording implements Playable {
	
	public String artistName;
	public String recordingName;
	public double recordingLength;
	public double recordingSize;
	
	public AudioRecording (String artistName, String recordingName, double recordingLength, double recordingSize) {
		this.artistName = artistName;
		this.recordingName = recordingName;
		this.recordingLength = recordingLength;
		this.recordingSize = recordingSize;
	}
	
	public String getArtistName() {
		return artistName;
	}
	
	public String getRecordingName() {
		return recordingName;
	}

	public double getRecordingLength() {
		return recordingLength;
	}
	
	public double getRecordingSize() {
		return recordingSize;
	}
	
	@Override
	public void play () {
		System.out.println("The audio recording: " + recordingName + " - " + artistName + " is playing for: " + recordingLength + " seconds.");
	}
	
	//Overloading
	public void play(AudioRecording [] thisPlaylist) {
		System.out.println("This set of audio recordings are playing:");
		for (int i = 0; i < thisPlaylist.length; i++) {
			System.out.println("The audio recording: " + thisPlaylist[i].getRecordingName() + " - " 
					+ thisPlaylist[i].getArtistName() + " is playing for: " 
					+ thisPlaylist[i].getRecordingLength() + " seconds.");
		}
		
	}

	
		
	
}
