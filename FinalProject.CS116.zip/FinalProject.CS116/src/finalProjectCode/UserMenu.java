package finalProjectCode;

import java.util.*;

public class UserMenu {

	//This class will be used for the database
	
	Playlist [] playlist1 = null;
	
	User user1 = new User("Mary");
	User user2 = new User("Rick");
	User user3 = new User("Emily");
	User user4 = new User("Victoria");
	
	
	User [] userDataBase = {user1, user2, user3, user4};
	
	
	public boolean isUser (int userID) {
		boolean isCurrentUser = false;
		for (int k = 0; k < userDataBase.length; k++) {
			if (userID == userDataBase[k].getID()) {
				isCurrentUser = true;
			}
			else isCurrentUser = false;
		}
		return isCurrentUser;
	}
		
	
	public void addUser(String name) {
		User newUser = new User(name);
			User [] temp = new User[userDataBase.length + 1];
			for (int i = 0; i < userDataBase.length; i++) {
				for (int j = 0; j < userDataBase.length; j++) {
					temp[j] = userDataBase[i];
				}
			}
			temp[userDataBase.length + 1] = newUser;
			System.out.println("A new user has been added");
	}
	
	
	public void removeUser(String userName) {
		int index = 0;
		User [] anotherArray = new User[userDataBase.length - 1];
		for (int i = 0; i < userDataBase.length; i++) {
			if (userName == userDataBase[i].getUserName()) {
				index = i;
			}
		}
		for (int i = 0, k = 0; i < userDataBase.length; i++) {
			if (i == index) {
				continue;				
			}
			anotherArray[k++] = userDataBase[i];
		}
		System.out.println("User has been removed");
		
	}
	
	public void removeUser(int userID) {
		int index;
		User [] anotherArray = new User[userDataBase.length - 1];
		for (int i = 0; i < userDataBase.length; i++) {
			if (userID == userDataBase[i].getID()) {
				index = i;
			}
		}
		for (int i = 0, k = 0; i < userDataBase.length; i++) {
			if (i == userID) {
				continue;				
			}
			anotherArray[k++] = userDataBase[i];
		}
		System.out.println("User has been removed");
	}
	
	
	
}
