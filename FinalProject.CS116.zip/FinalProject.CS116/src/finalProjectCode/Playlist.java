package finalProjectCode;

import java.util.*;

public class Playlist implements Playable {

	
	User thisUser;
	private double playlistLength = 0;
	private double playlistSize = 0;
	
	AudioRecording audio1 = new AudioRecording("Ed Sheeran", "Castle On the Hill", 262.0, 160.0);
	AudioRecording audio2 = new AudioRecording("Alexander 23", "IDK You Yet", 186.0, 60.0);
	AudioRecording audio3 = new AudioRecording("The Lumineers", "Cleopatra", 190.0, 60.0);
	VideoRecording video1 = new VideoRecording("Niall Horan", "Niall Horan - Flicker (Acoustic)", 259.0, 29.97);
	VideoRecording video2 = new VideoRecording("Chris Renzema", "How To Be Yours", 289.0, 29.97);
	
	
	//Not sure how to make it so that I can have both audio and video recordings in a playlist
	Playlist [] playlist1 = {audio1, video1, audio2, video2, audio3};
	
	
	public void addRecording(VideoRecording thisVideo) {
		Playlist[] temp = new Playlist[playlist1.length + 1];
		for (int i = 0; i < playlist1.length; i++) {
			for (int j = 0; j < playlist1.length; j++) {
				temp[j] = playlist1[i];
			}
		}
		temp[playlist1.length + 1] = thisVideo;
		System.out.println("A new video recording has been added");
	}
	
	public void addRecording(AudioRecording thisAudio) {
		Playlist[] temp = new Playlist[playlist1.length + 1];
		for (int i = 0; i < playlist1.length; i++) {
			for (int j = 0; j < playlist1.length; j++) {
				temp[j] = playlist1[i];
			}
		}
		temp[playlist1.length + 1] = thisAudio;
		System.out.println("A new audio recording has been added");
	}
	
	public void removeRecording(String title, boolean isVideo) {
		if (isVideo == true) {
			int index = 0;
			Playlist [] anotherArray = new Playlist[playlist1.length - 1];
			for (int i = 0; i < playlist1.length; i++) {
				if (title == playlist1[i].getRecordingName()) {
					index = i;
				}
			}
			for (int i = 0, k = 0; i < playlist1.length; i++) {
				if (i == index) {
					continue;				
				}
				anotherArray[k++] = playlist1[i];
			}
			System.out.println("Video recording has been removed");
		}
		else if (isVideo == false) {
			int index = 0;
			Playlist [] anotherArray = new Playlist[playlist1.length - 1];
			for (int i = 0; i < playlist1.length; i++) {
				if (title == playlist1[i].getRecordingName()) {
					index = i;
				}
			}
			for (int i = 0, k = 0; i < playlist1.length; i++) {
				if (i == index) {
					continue;				
				}
				anotherArray[k++] = playlist1[i];
			}
			System.out.println("Audio recording has been removed");
		}
	}
	
	public void removeRecording(int recordingIndex, boolean isVideo) {
		if (isVideo == true) {
			Playlist [] anotherArray = new Playlist[playlist1.length - 1];
			for (int i = 0, k = 0; i < playlist1.length; i++) {
				if (i == recordingIndex) {
					continue;				
				}
				anotherArray[k++] = playlist1[i];
			}
			System.out.println("Video has been removed");
		}
		else if (isVideo == false) {
			Playlist [] anotherArray = new Playlist[playlist1.length - 1];
			for (int i = 0, k = 0; i < playlist1.length; i++) {
				if (i == recordingIndex) {
					continue;				
				}
				anotherArray[k++] = playlist1[i];
			}
			System.out.println("Audio has been removed");
		}
	}

	@Override
	public void play() {
		for (int i = 0; i < playlist1.length; i++) {
			System.out.println("The recording: " + playlist1[i].getRecordingName() + " - " 
					+ playlist1[i].getArtistName() + " is playing for: " 
					+ playlist1[i].getRecordingLength() + " seconds.");
		}		
	}


	public void shufflePlaylist(int userID) {
		Random rand = new Random();
		int upNext;
		for (int i = 0; i < playlist1.length; i++) {
			upNext = rand.nextInt(playlist1.length);
			System.out.println("The recording: " + playlist1[upNext].getRecordingName() + " - " 
					+ playlist1[upNext].getArtistName() + " is playing for: " 
					+ playlist1[upNext].getRecordingLength() + " seconds.");
		}
		
	}

	public String statistics() {
		String message;
		int totalRecordings = playlist1.length - 1;
		double totalLength = 0.0;
		double totalSize = 0.0;
		for (int i = 0; i < playlist1.length; i++) {
			totalLength = totalLength + playlist1[i].getRecordingLength();
			totalSize = totalSize + playlist1[i].getRecordingSize();
		}
		message = "The total recordings on the playlist are: " + totalRecordings
				+ ". \n The total length of the playlist is: " + totalLength + " seconds. \n"
				+ "The total size of the playlist is: " + totalSize;
		return message;
	}

	
}
