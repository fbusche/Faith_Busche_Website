package finalProject;

import java.util.Scanner;

public class Account {

	Scanner scan = new Scanner(System.in);
	
	//Variables
	private User mainUser;
	private User [] friendArray;
	private User [] friendsToSplit;
	private Purchase purchase1;
	
	//Constructors
	public Account(User mainUser, User [] friendArray, User [] friendsToSplit, Purchase purchase1) {
		this.mainUser = mainUser;
		this.friendArray = friendArray;
		this.friendsToSplit = friendsToSplit;
		this.purchase1 = purchase1;
	}
	
	//Setters and Getters
	public void setMainUser(User mainUser) {
		this.mainUser = mainUser;
	}
	
	public void setFriendArray(User [] friendArray) {
		this.friendArray = friendArray;
	}
	
	public void setFriendsToSplit(User [] friendsToSplit) {
		this.friendsToSplit = friendsToSplit;
	}
	
	public void setPurchase1(Purchase purchase1) {
		this.purchase1 = purchase1;
	}
	
	public User getMainUser() {
		return mainUser;
	}
	
	public User [] getFriendArray() {
		return friendArray;
	}
	
	public User [] getFriendsToSplit() {
		return friendsToSplit;
	}
	
	public Purchase purchase1() {
		return purchase1;
	}
	
	//addFriend() method
	public String addFriend(User [] friendArray, User notFriend) {
		String response = "null";
		for (int i = 0; i < friendArray.length; i++) {	
			if (notFriend.getUserID() != friendArray[i].getUserID()) {
				User newFriend = new User(notFriend.getPasssword(), notFriend.getCurrentBalance());
				for (int j = 0; j < friendArray.length; j++) {
					if (friendArray[j] != null) {
						j++;
					}
					else {
						friendArray[j] = newFriend;
					}
				}
				response = "This user is now a friend.";
			}
			else if (notFriend.getUserID() == friendArray[i].getUserID()) {
				response = "This user is already a friend.";
			}
		}
		System.out.println(response);
		return response;
	}
	
	//deleteFriend() method
	public String deleteFriend(User [] friendArray, User certainFriend) {
		String response = "null";
		for (int i = 0; i < friendArray.length; i++) {
			if (certainFriend.getUserID() == friendArray[i].getUserID()) {
				friendArray[i] = null;
				response = "Friend has been deleted.";
			}
			else {
				response = "This user is not a friend.";
			}
		}
		System.out.println(response);
		return response;
	}
	
	//changePassword() method
	public String changePassword(User mainUser) {
		System.out.println("Enter current password");
		String enteredPass = scan.next();
		String passStatus = "Password unchanged";
		if (enteredPass.contentEquals(mainUser.getPasssword())) {
			System.out.println("Enter new password");
			String newPass = scan.next();
			mainUser.setPassword(newPass);
			passStatus = "Password changed";
		}
		else {
			passStatus = "Incorrect password";
		}
		System.out.println(passStatus);
		return passStatus;
	}
	
}
