package finalProject;

public class User {

	public static int IdGenerator = 0;
		
		private String password;
		private int userID;
		private double currentBalance;
		
		public User(String password, double currentBalance) {
			this.password = password;
			this.userID = IdGenerator;
			this.currentBalance = currentBalance;
			IdGenerator++;
		}
		
		//Setters
		public void setPassword(String password) {
			this.password = password;
		}
		
		public void setCurrentBalance(double currentBalance) {
			this.currentBalance = currentBalance;
		}
		
		//Getters
		public String getPasssword() {
			return password;
		}
		
		public int getUserID() {
			return userID;
		}
		
		public double getCurrentBalance() {
			return currentBalance;
		}
	
		//equals() method
		public boolean equals(User thisUser) {
			if (password == thisUser.password && currentBalance == thisUser.currentBalance) {
				return true;
			}
			return false;
		}
				
}
