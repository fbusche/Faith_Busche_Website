package finalProject;

import java.util.Scanner;

public class CashApp {

	
	public static int idcounter = 0;
	
	public static void main(String[] args) {
			
		//Creating the user
		Scanner scan = new Scanner(System.in);
		System.out.println("Create a password");
		String mainPass = scan.nextLine();
		
		User mainUser = new User(mainPass, 10.0);
		int mainID = idcounter;
		
		System.out.println("Your ID number is " + mainID);
		
		//Logging in
		System.out.println("Please enter your ID number");
		int enteredID = scan.nextInt();
		System.out.println("Please enter your password");
		String enteredPass = scan.next();
		
		boolean loginStatus = false;
		
		if (enteredID == mainUser.getUserID() && enteredPass.contentEquals(mainUser.getPasssword())) {
			loginStatus = true;
			System.out.println("Username and Password correct");
		}
		else if (enteredID != mainUser.getUserID() && enteredPass.contentEquals(mainUser.getPasssword())) {
			loginStatus = false;
			System.out.println("Username incorrect");
		}
		else if (enteredID == mainUser.getUserID() && enteredPass != mainUser.getPasssword()) {
			loginStatus = false;
			System.out.println("Pass incorrect");
		}
		else {
			loginStatus = false;
			System.out.println("Username and Password incorrect");
		}
				
		//Now in the account
		if (loginStatus == true) {
			System.out.println("Please select an option \n" 
					+ "1 = add friend \n" + "2 = delete friend \n" + "3 = change password \n" 
					+ "4 = check balance \n" + "5 = add purchase \n"  
					+ "6 = deposit money \n" + "7 = exit app");	
		}
		int selection = scan.nextInt();
		
		//Friends List - these are just made up people that have set things for their accounts and their id numbers are automatically created as well
		User friend1 = new User("password1", 0.0);
		User friend2 = new User("password2", 1.0);
		
		User [] friendArray1 = new User [9];
		friendArray1[0] = friend1;
		friendArray1[1] = friend2;
		
		
		Purchase thisPurchase = new Purchase(mainUser, "food", 100.0, friendArray1);
		Account mainAccount = new Account(mainUser, friendArray1, friendArray1, thisPurchase);
		
		//1 - add friend
		if (selection == 1) {
			System.out.println("Enter the password of the friend you would like to add");
			String friendPass = scan.next();
			System.out.println("Enter the current balance of the friend you would like to add");
			double friendBalance = scan.nextInt();
			User newFriend = new User(friendPass, friendBalance);
			mainAccount.addFriend(friendArray1, newFriend);
		}
		
		//2 - delete friend
		else if (selection == 2) {
			System.out.println("Enter the password of the friend you would like to delete");
			String friendPass = scan.next();
			System.out.println("Enter the current balance of the friend you would like to delete");
			int friendBalance = scan.nextInt();
			User notFriend = new User(friendPass, friendBalance);
			mainAccount.deleteFriend(friendArray1, notFriend);
		}
		
		//3 - change password
		else if (selection == 3) {
			mainAccount.changePassword(mainUser);
		}
		
		//4 - check balance
		else if (selection == 4) {
			System.out.println(mainUser.getCurrentBalance());
		}
		
		//5 - add purchase
		else if (selection == 5) {
			System.out.println("What is the name of the item?");
			String itemName = scan.next();
			System.out.println("What is the price of the purchase?");
			double itemPrice = scan.nextDouble();
			System.out.println("How many people do you want to split this with, not including yourself?");
			double numberOfFriends = ((scan.nextDouble()) + 1);
			Purchase purchase1 = new Purchase(mainUser, itemName, itemPrice, friendArray1);
			purchase1.makePurchase(itemPrice, numberOfFriends);
		}
		
		//6 - add money to the account
		else if (selection == 6) {
			System.out.println("Enter your 16 digit credit card number with no spaces: ");
			String cardNumber = scan.next();
			if (cardNumber.length() == 16) {
				System.out.println("Enter the amount you would like to add to your account: ");
				double deposit = scan.nextDouble();
				double previousBalance = mainUser.getCurrentBalance();
				mainUser.setCurrentBalance(previousBalance + deposit);
				System.out.println("Your new current balance is: " + mainUser.getCurrentBalance());
			}
			else {
				System.out.println("Invalid card.");
			}
		}
		
		//7 - exit application
		else if (selection == 7) {
			System.out.println("Logged out.");
		}
		else {
			System.out.println("Not an option.");
		}
		
		scan.close();	
		
	}

}
