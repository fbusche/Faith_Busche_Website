package finalProject;

import java.util.Scanner;

public class Purchase {

	Scanner scan = new Scanner(System.in);
	
	private User mainUser;
	//private User [] friendArray;
	private String itemName;
	private double itemPrice;
	private User [] friendsToSplit;
	private User [] temp;
	private Account account1;
	
	
	public Purchase(User mainUser, String itemName, double itemPrice, User [] friendsToSplit) {
		this.mainUser = mainUser;		
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.friendsToSplit = new User[friendsToSplit.length];
		this.friendsToSplit = friendsToSplit;
	}
	
	//Setters
	public void setMainUser(User mainUser) {
		this.mainUser = mainUser;
	}
	
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}
	
	public void setFriendsToSplit(User [] friendsToSplit, User [] friendArray) {
		if (friendsToSplit.length <= 10) {
			friendsToSplit = checkFriend(friendArray, friendArray, account1);
			int i = 0;
			while (i < friendsToSplit.length) {
				this.friendsToSplit[i] = friendsToSplit[i];
			}	
		}
	}
	
	//Getters
	public User getMainUser() {
		return mainUser;
	}
	
	public String getItemName() {
		return itemName;
	}
	
	public double getItemPrice() {
		return itemPrice;
	}
	
	public User [] getFriendsToSplit() {
		for (int i = 0; i < friendsToSplit.length; i++) {
			temp[i] = friendsToSplit[i];
		}
		return temp;
	}
	
	//checkFriend() method
		public User[] checkFriend(User [] friendsToSplit, User [] friendArray, Account account1) {
		User notFriend = null;
		for (int i = 0; i < friendArray.length; i++) {
			for (int j = 0; j < friendsToSplit.length; j++) {	
				if (friendsToSplit[j].getUserID() != friendArray[i].getUserID()) {
					account1.addFriend(friendArray, notFriend);
				}
			}
		}
		return friendsToSplit;
	}
		
	public double pricePerPerson(double itemPrice, double numberOfPeople) {
		double owedEach = (itemPrice / numberOfPeople);
		return owedEach;
	}
	
	//makePurchase() method
	public void makePurchase(double itemPrice, double numberOfPeople) {
		System.out.println("Each person will owe: " + pricePerPerson(itemPrice, numberOfPeople));
		mainUser.setCurrentBalance(mainUser.getCurrentBalance() - pricePerPerson(itemPrice, numberOfPeople));
		System.out.println("Your new balance is: " + mainUser.getCurrentBalance());
	}
}
